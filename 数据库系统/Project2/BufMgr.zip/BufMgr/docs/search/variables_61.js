var searchData=
[
  ['accesses',['accesses',['../structbadgerdb_1_1_buf_stats.html#a3e7eb386ac728ed028bd2a8bb7960827',1,'badgerdb::BufStats']]]
];
